# Feirou — Pix automático, Firebase e apps móveis

Este pacote adiciona uma primeira integração de Pix por Mercado Pago no backend Firebase Functions e prepara o projeto para Android/iOS com Capacitor.

## O que foi preparado
- Função autenticada `createPixPayment`: calcula o total usando o anúncio no Firestore e cria a cobrança Pix no servidor.
- Função `mercadoPagoWebhook`: consulta o pagamento diretamente na API do Mercado Pago e só marca como pago quando a API confirmar `approved`.
- A tela de compra solicita o Pix ao backend e mostra QR Code, código copia e cola e link de pagamento.
- Configuração inicial do Capacitor para Android e iOS.

**Ainda não está ativo em produção.** É obrigatório configurar seu próprio Firebase e sua conta Mercado Pago, usar credenciais de teste primeiro e validar o fluxo ponta a ponta. Não coloque Access Token no HTML nem envie segredo pelo chat.

## 1. Firebase
1. Crie/seleciona um projeto no Firebase Console.
2. Ative Authentication (E-mail/senha e Google, se desejar) e Firestore.
3. Copie a configuração do app Web para `public/firebase-config.js`.
4. No terminal, na pasta do projeto:

```bash
npm install
cd functions && npm install && cd ..
npm install -g firebase-tools
firebase login
firebase use --add
```

5. Cloud Functions e Secret Manager exigem habilitar faturamento (plano Blaze) para deploy/execução conforme uso. Consulte preços e limites antes de ativar.
6. Configure o token privado do Mercado Pago como segredo:

```bash
firebase functions:secrets:set MP_ACCESS_TOKEN
```

Cole primeiro a credencial de TESTE do Mercado Pago. Nunca use token privado no navegador.
7. Publique regras, hosting e funções:

```bash
firebase deploy
```

## 2. Mercado Pago / Pix
1. Crie uma aplicação no painel de desenvolvedores do Mercado Pago.
2. Use credenciais de teste e uma conta de teste de vendedor/comprador para validar.
3. Configure a URL de webhook apresentada pela função `mercadoPagoWebhook` no painel, se necessário.
4. Teste: criar pedido, gerar QR, pagar no ambiente de teste, receber webhook e conferir que o pedido muda para `pago`.
5. Só depois da validação, troque para credenciais de produção e revise taxas, política de reembolso, chargeback e obrigações fiscais.

A integração atual recebe o valor total pelo Mercado Pago. Ela **não implementa split automático da comissão entre vendedor e plataforma**. Para repasse automático, será necessário habilitar e implementar o produto de marketplace/split compatível com a conta do provedor.

## 3. Android
Requisitos: Node.js, Android Studio e Android SDK.

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

No Android Studio, configure assinatura e gere APK (teste/distribuição direta) ou AAB (Google Play). Guarde a chave de assinatura.

## 4. iOS
Requisitos: macOS, Xcode, ferramentas de linha de comando e conta Apple Developer para distribuição.

```bash
npm install
npx cap add ios
npx cap sync ios
npx cap open ios
```

A compilação e assinatura iOS precisam ser feitas no Xcode em um Mac. Não é possível gerar um IPA assinado neste ambiente Linux.

## 5. Pendências importantes antes de produção
- Completar configuração real do Firebase (o arquivo `public/firebase-config.js` ainda tem marcadores `COLE_AQUI`).
- Configurar autenticação, domínios autorizados e regras Firestore revisadas.
- A função de webhook consulta a API do Mercado Pago antes de confiar no estado, mas deve ser submetida a revisão de segurança e testes de repetição/concorrência antes de produção.
- Implementar split/repasse, reembolso, cancelamento e reconciliação de pagamentos se o modelo comercial exigir.
- Revisar LGPD, termos, política de privacidade e dados coletados.
- Validar acessibilidade, navegação nativa, notificações push e testes em dispositivos reais.
