// Cole aqui os dados do seu app Web (Console Firebase > Configurações do projeto > Seus apps)
export const firebaseConfig = {
  apiKey: "COLE_AQUI",
  authDomain: "SEU-PROJETO.firebaseapp.com",
  projectId: "SEU-PROJETO",
  appId: "COLE_AQUI"
};
