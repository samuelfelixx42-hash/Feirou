const {onCall, onRequest, HttpsError} = require('firebase-functions/v2/https');
const {defineSecret} = require('firebase-functions/params');
const {initializeApp} = require('firebase-admin/app');
const {getFirestore, FieldValue} = require('firebase-admin/firestore');
const {randomUUID} = require('crypto');

initializeApp();
const db = getFirestore();
const MP_ACCESS_TOKEN = defineSecret('MP_ACCESS_TOKEN');

// Cria cobrança Pix no servidor. O preço e o vendedor são sempre lidos do Firestore.
exports.createPixPayment = onCall({region: 'southamerica-east1', secrets: [MP_ACCESS_TOKEN]}, async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Entre na sua conta.');
  const {listingId, quantity, contact, note = ''} = request.data || {};
  const qty = Number(quantity);
  if (typeof listingId !== 'string' || !Number.isInteger(qty) || qty < 1 || qty > 20 || typeof contact !== 'string' || !contact.trim()) {
    throw new HttpsError('invalid-argument', 'Dados do pedido inválidos.');
  }
  const listingRef = db.collection('listings').doc(listingId);
  const snap = await listingRef.get();
  if (!snap.exists) throw new HttpsError('not-found', 'Anúncio não encontrado.');
  const item = snap.data();
  if (item.status !== 'active' || item.seller === request.auth.uid || !Number.isFinite(item.price) || item.price <= 0 || item.stock < qty) {
    throw new HttpsError('failed-precondition', 'Anúncio indisponível ou estoque insuficiente.');
  }
  const userSnap = await db.collection('users').doc(request.auth.uid).get();
  const authEmail = request.auth.token.email;
  if (!authEmail) throw new HttpsError('failed-precondition', 'Sua conta precisa ter um e-mail válido.');
  const total = Math.round(item.price * qty * 100) / 100;
  const orderRef = db.collection('orders').doc();
  const idempotencyKey = randomUUID();
  await orderRef.set({
    listing: listingId, title: item.title, price: item.price, qty,
    buyer: request.auth.uid, buyerName: request.auth.token.name || authEmail,
    seller: item.seller, sellerName: item.sellerName || '', contact: contact.trim().slice(0, 80),
    note: String(note).slice(0, 200), pay: 'Pix', status: 'aguardando_pagamento',
    paymentProvider: 'mercado_pago', amount: total, created: Date.now(), stockCommitted: false
  });
  const response = await fetch('https://api.mercadopago.com/v1/payments', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${MP_ACCESS_TOKEN.value()}`,
      'Content-Type': 'application/json',
      'X-Idempotency-Key': idempotencyKey
    },
    body: JSON.stringify({
      transaction_amount: total,
      description: `Feirou - ${String(item.title).slice(0, 100)}`,
      payment_method_id: 'pix',
      payer: {email: authEmail},
      external_reference: orderRef.id,
      notification_url: `https://${process.env.GCLOUD_PROJECT}.cloudfunctions.net/mercadoPagoWebhook`,
      metadata: {order_id: orderRef.id, listing_id: listingId, buyer_uid: request.auth.uid}
    })
  });
  const payment = await response.json();
  if (!response.ok) {
    await orderRef.update({status: 'falha_pagamento', paymentError: payment.message || 'provider_error'});
    throw new HttpsError('internal', 'Não foi possível gerar o Pix. Confira as credenciais e os dados da conta.');
  }
  const txData = payment.point_of_interaction?.transaction_data || {};
  await orderRef.update({paymentId: String(payment.id), paymentStatus: payment.status || 'pending'});
  return {
    orderId: orderRef.id,
    qrCode: txData.qr_code || '',
    qrCodeBase64: txData.qr_code_base64 || '',
    ticketUrl: txData.ticket_url || ''
  };
});

// Webhook não confia no payload recebido: consulta o pagamento diretamente no Mercado Pago.
exports.mercadoPagoWebhook = onRequest({region: 'southamerica-east1', secrets: [MP_ACCESS_TOKEN]}, async (req, res) => {
  if (req.method !== 'POST' && req.method !== 'GET') return res.status(405).send('Method not allowed');
  const paymentId = req.query['data.id'] || req.body?.data?.id || req.body?.id;
  if (!paymentId) return res.status(200).send('Ignored');
  try {
    const check = await fetch(`https://api.mercadopago.com/v1/payments/${encodeURIComponent(paymentId)}`, {
      headers: {Authorization: `Bearer ${MP_ACCESS_TOKEN.value()}`}
    });
    const payment = await check.json();
    if (!check.ok) return res.status(502).send('Could not verify payment');
    const orderId = payment.external_reference || payment.metadata?.order_id;
    if (!orderId) return res.status(200).send('No order reference');
    const orderRef = db.collection('orders').doc(String(orderId));
    await db.runTransaction(async (tx) => {
      const orderSnap = await tx.get(orderRef);
      if (!orderSnap.exists) return;
      const order = orderSnap.data();
      // Confere vínculo, moeda e valor antes de aceitar a confirmação do provedor.
      if (String(order.paymentId || '') !== String(payment.id) || payment.currency_id !== 'BRL' ||
          Math.round(Number(payment.transaction_amount) * 100) !== Math.round(Number(order.amount) * 100)) {
        console.warn('Payment/order mismatch', {orderId, paymentId: payment.id});
        return;
      }
      tx.update(orderRef, {paymentStatus: payment.status, paymentUpdated: Date.now()});
      if (payment.status !== 'approved' || order.stockCommitted) return;
      const listingRef = db.collection('listings').doc(order.listing);
      const listingSnap = await tx.get(listingRef);
      if (!listingSnap.exists || listingSnap.data().stock < order.qty) {
        tx.update(orderRef, {status: 'revisao_estoque'});
        return;
      }
      tx.update(listingRef, {stock: listingSnap.data().stock - order.qty});
      tx.update(orderRef, {status: 'pago', stockCommitted: true, paidAt: Date.now(), providerPaymentId: String(payment.id)});
    });
    return res.status(200).send('OK');
  } catch (err) {
    console.error('Webhook processing error', err);
    return res.status(500).send('Retry');
  }
});
