# Feirou — pacote Android

Marketplace web/PWA empacotado com Capacitor 7. O projeto inclui Firebase/Firestore, Cloud Functions para criação e verificação de cobrança Pix via Mercado Pago e interface móvel.

## Gerar APK

O ambiente de execução desta entrega não possui Android SDK nem acesso de rede para baixar as ferramentas; portanto o APK binário não pode ser compilado aqui. Foi incluído o workflow `.github/workflows/android-apk.yml`: envie esta pasta para um repositório GitHub e execute **Actions → Build Feirou APK → Run workflow**. O APK de depuração será publicado em **Artifacts → feirou-debug-apk**.

Localmente, com Node 22, Java 21 e Android SDK instalados: `npm install`, `npx cap add android`, `npx cap sync android`, `cd android && ./gradlew assembleDebug`.

## Antes de usar com usuários reais

1. Configure `public/firebase-config.js` com os dados do seu app Web Firebase (os valores atuais são marcadores e não conectam a um projeto).
2. Ative Authentication e Firestore; publique `firestore.rules` e faça deploy das Functions.
3. Configure o segredo `MP_ACCESS_TOKEN` no Firebase Secret Manager e teste com credenciais de teste do Mercado Pago.
4. Cadastre o UID administrativo na coleção `admins` pelo Console do Firebase.
5. Informe nome/empresa e e-mail de contato reais na política de privacidade.
6. Configure domínio, webhook, termos, reembolsos e split de marketplace. A integração atual cobra via Pix, mas não faz split automático de comissão.

**Importante:** não publique este pacote como serviço financeiro ativo antes de preencher as configurações, testar o fluxo ponta a ponta e revisar regras, LGPD e segurança. O APK de depuração não é uma versão assinada para Play Store.
