# APK Android

O workflow de GitHub Actions compila `app-debug.apk` automaticamente em runner com Android SDK. O artefato é de depuração, instalável para testes. Para distribuição pública, gere uma versão release assinada com chave própria e mantenha a chave fora do repositório.

A compilação não configura Firebase nem Mercado Pago: isso exige credenciais do titular do serviço. Nunca coloque Access Token do Mercado Pago no app ou no repositório.
